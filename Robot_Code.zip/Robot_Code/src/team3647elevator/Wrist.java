public class Wrist 
{
	public static int elevatorState, aimedElevatorState;
	/*
	 * 0. Start
	 * 1. Flat
	 * 2. Sixty-Degrees
	 * 3. Facing Up
	 */

	public static boolean start, flat, sixtyDegrees, up, manualOverride, originalPositionButton;
	public static double overrideValue, speed, wristEncoder; 

	//Insert step 1 code below
	

	//Insert step 3 code below
	public static void setLimitSwitch()
	{
		flat = limitSwitch.get();
	}
}
